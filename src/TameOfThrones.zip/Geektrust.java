import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Geektrust {
	public static void main(String args[]) {
		try {
	        
			List<String> output = new ArrayList<String>();
			output.add("SPACE");
			File file = new File(args[0]);		
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			
			//hashmap to map kingdoms with emblems
			Map<String,String> emblemMap = new HashMap<String,String>();
			emblemMap.put("LAND", "panda");
			emblemMap.put("WATER", "octopus");
			emblemMap.put("ICE", "mammoth");
			emblemMap.put("AIR", "owl");
			emblemMap.put("FIRE", "dragon");

			String line; 
			while((line=bufferedReader.readLine())!=null)  
			{  
				String lineArr[] = line.split(" ");
				String kingdom = lineArr[0];
				String emblem = emblemMap.get(lineArr[0]);
				int lengthOfEmblem = emblem.length();
				String encryptedString = lineArr[1].toLowerCase();
				if(lineArr.length>2) {
					encryptedString="";
					for(int i =1;i<lineArr.length ;i++) {
						encryptedString+=lineArr[i];
					}
				}
				encryptedString= encryptedString.toLowerCase();
				
				String decryptedString ="";
				for(int i =0;i< encryptedString.length(); i++) {
					int index = encryptedString.charAt(i)-lengthOfEmblem;
					if(index<97) {
						index = 123 - lengthOfEmblem + encryptedString.charAt(i)-97;
					}
					char s =(char) (index);
					decryptedString+=s;
				}
				
				

			
				for(int i=0; i<decryptedString.length();i++) {
					if(emblem.indexOf(decryptedString.charAt(i)+"")>=0) {
						int index = emblem.indexOf(decryptedString.charAt(i)+"");
						emblem = emblem.substring(0,index)+emblem.substring(index+1, emblem.length());
						
					}
				}

				if(emblem.length()==0) {
					if(!output.contains(kingdom))
						output.add(kingdom);
				}
			}  
			
			if(output.size()<3) {
				output.clear();
				output.add("NONE");

			}
			
			String result ="";
			for(String kingdoms: output) {
				result +=  kingdoms+" ";
			}
			
			result = result.substring(0, result.length()-1);
			System.out.println(result);
			
		}
		catch(Exception e) {
			System.out.println("Exception "+e);
		}

	}
}
